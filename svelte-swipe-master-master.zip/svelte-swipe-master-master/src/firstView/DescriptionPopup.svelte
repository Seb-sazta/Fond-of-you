<script>
  export let description = undefined;
</script>


<div class="white-back">
<h1>Litt om meg! </h1>
<span>
	{description}
</span>
</div>



<style>

  h1 {
		font-size: 2rem;
		text-align: center;
		color: #000000;
		
	}

	.white-back {
		background-color: #ffffff;
		color: #000000;	
		padding: 15px;
		border-radius: 10px;
	
	}

.white-back span{ 
	font-size: 12pt;
	line-height: 1.2;
}

</style>
