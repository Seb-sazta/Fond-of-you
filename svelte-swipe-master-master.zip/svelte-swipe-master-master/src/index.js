export { default as Index } from './firstView/Index.svelte';
export { default as Main } from './firstView/Main.svelte';